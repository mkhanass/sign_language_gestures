# 🤟 Sign Language Gestures — ASL Real-Time Detection

A real-time American Sign Language (ASL) gesture detection web app using Python, Flask, MediaPipe, and OpenCV.

---

## 📁 Project Structure

```
sign_language_gestures/
├── app.py                  ← Main Flask application
├── requirements.txt        ← Python dependencies
├── README.md               ← This file
├── templates/
│   └── index.html          ← Frontend UI
├── static/
│   ├── css/
│   ├── js/
│   └── images/
├── models/                 ← (for future ML models)
└── utils/                  ← (utility modules)
```

---

## ⚙️ Step-by-Step Setup Guide (PyCharm)

### STEP 1 — Open Project in PyCharm
1. Launch **PyCharm**
2. Click **File → Open**
3. Navigate to and select the `sign_language_gestures` folder
4. Click **OK**

---

### STEP 2 — Create a Virtual Environment
1. Go to **File → Settings** (Windows/Linux) or **PyCharm → Preferences** (Mac)
2. Navigate to **Project: sign_language_gestures → Python Interpreter**
3. Click the gear icon ⚙️ → **Add Interpreter → Add Local Interpreter**
4. Select **Virtualenv Environment**
5. Choose **New environment**
6. Set location (default is fine, e.g., `venv` inside the project folder)
7. Base interpreter: Select **Python 3.9 / 3.10 / 3.11**
8. Click **OK**

---

### STEP 3 — Install Dependencies
**Option A — via PyCharm Terminal:**
1. Open Terminal in PyCharm: **View → Tool Windows → Terminal**
2. Make sure your venv is activated (you'll see `(venv)` in the prompt)
3. Run:
   ```bash
   pip install -r requirements.txt
   ```

**Option B — via PyCharm GUI:**
1. Go to **File → Settings → Python Interpreter**
2. Click **+** to add packages
3. Install each package listed in `requirements.txt`

> ⏳ **Note:** MediaPipe and OpenCV are large packages. Installation may take 2–5 minutes.

---

### STEP 4 — Configure Run Configuration
1. Click the **Run** menu → **Edit Configurations**
2. Click **+** → **Python**
3. Fill in:
   - **Name:** `Sign Language App`
   - **Script path:** Browse to `app.py`
   - **Working directory:** The project root folder
4. Click **OK**

---

### STEP 5 — Run the Application
1. Click the **▶ Run** button (or press `Shift + F10`)
2. Wait for the server to start — you'll see:
   ```
   🤟 Sign Language Gesture Detection Server Starting...
   📡 Open http://127.0.0.1:5000 in your browser
   ```
3. Open your browser and go to: **http://127.0.0.1:5000**

---

### STEP 6 — Use the App
1. Click **"Start Camera"** button
2. Allow camera access in the browser popup
3. Show your hand to the camera and make ASL gestures
4. The app will detect and display:
   - The detected letter (A–Z)
   - Confidence percentage
   - Detection history

---

## 🎯 Supported ASL Gestures

| Letter | Hand Shape Description |
|--------|------------------------|
| A | Closed fist with thumb on side |
| B | Four fingers up, thumb across palm |
| D | Index finger up, others curved |
| I | Only pinky finger extended |
| L | Index up + thumb out (L shape) |
| O | All fingers curve to meet thumb |
| S | Closed fist, thumb over fingers |
| V | Index & middle spread (peace sign) |
| W | Index, middle & ring spread |
| Y | Thumb & pinky extended |
| ... | And more! |

---

## 🛠️ Troubleshooting

**❌ `ModuleNotFoundError: No module named 'mediapipe'`**
→ Make sure the virtual environment is activated and run `pip install -r requirements.txt`

**❌ Camera not working in browser**
→ Make sure you're accessing via `http://127.0.0.1:5000` (not `https://` or a remote IP)
→ Allow camera permissions in your browser settings

**❌ `Address already in use` on port 5000**
→ Another app is using port 5000. Stop it, or change port in `app.py`:
```python
socketio.run(app, port=5001)
```

**❌ MediaPipe installation fails on Python 3.12+**
→ Use Python 3.9, 3.10, or 3.11 for best compatibility

---

## 📦 Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| Flask | 3.0.0 | Web framework |
| flask-socketio | 5.3.6 | Real-time communication |
| mediapipe | 0.10.9 | Hand landmark detection |
| opencv-python | 4.9.0.80 | Image processing |
| numpy | 1.26.4 | Numerical operations |
| eventlet | 0.35.2 | Async server support |

---

## 💡 How It Works

1. **Camera Feed** → Browser captures webcam frames via JavaScript
2. **Socket.IO** → Frames are sent to the Python server in real-time
3. **MediaPipe** → Detects 21 hand landmarks per hand
4. **Gesture Classifier** → Analyzes finger positions to determine ASL letter
5. **OpenCV** → Draws bounding boxes and annotations on the frame
6. **Response** → Annotated frame + gesture data sent back to browser

---

*Built with ❤️ using Flask + MediaPipe + OpenCV*
