import cv2
import numpy as np
import base64
from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
import mediapipe as mp
import json
import time

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sign_language_secret'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# MediaPipe setup
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=2,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.5
)

# ASL Gesture mapping (based on hand landmarks)
ASL_GESTURES = {
    'A': 'Closed fist with thumb on side',
    'B': 'Four fingers up, thumb across palm',
    'C': 'Curved hand like letter C',
    'D': 'Index up, others curved',
    'E': 'All fingers curled',
    'F': 'Index & thumb touch, others up',
    'G': 'Index points sideways, thumb parallel',
    'H': 'Index & middle point sideways',
    'I': 'Pinky up, others closed',
    'J': 'Pinky traces J in air',
    'K': 'Index & middle up, thumb between',
    'L': 'Index up, thumb out (L shape)',
    'M': 'Thumb under 3 fingers',
    'N': 'Thumb under 2 fingers',
    'O': 'All fingers curve to meet thumb',
    'P': 'K shape pointing down',
    'Q': 'G shape pointing down',
    'R': 'Crossed index & middle fingers',
    'S': 'Closed fist, thumb over fingers',
    'T': 'Thumb between index & middle',
    'U': 'Index & middle up together',
    'V': 'Index & middle spread (peace)',
    'W': 'Index, middle & ring spread',
    'X': 'Index finger hooked',
    'Y': 'Thumb & pinky out',
    'Z': 'Index traces Z in air'
}

def calculate_distance(p1, p2):
    return np.sqrt((p1.x - p2.x)**2 + (p1.y - p2.y)**2)

def get_finger_states(landmarks):
    """Returns which fingers are extended"""
    tips = [4, 8, 12, 16, 20]
    pip = [3, 6, 10, 14, 18]
    states = []
    
    # Thumb (special case - compare x coordinates)
    if landmarks[4].x < landmarks[3].x:
        states.append(1)  # extended
    else:
        states.append(0)
    
    # Other fingers
    for i in range(1, 5):
        if landmarks[tips[i]].y < landmarks[pip[i]].y:
            states.append(1)
        else:
            states.append(0)
    
    return states  # [thumb, index, middle, ring, pinky]

def classify_gesture(landmarks):
    """Simple gesture classifier based on finger states"""
    if not landmarks:
        return None, 0.0
    
    states = get_finger_states(landmarks)
    thumb, index, middle, ring, pinky = states
    
    # Count extended fingers
    extended = sum(states)
    
    confidence = 0.75
    
    # L shape - thumb and index extended
    if thumb == 1 and index == 1 and middle == 0 and ring == 0 and pinky == 0:
        return 'L', 0.88
    
    # Y shape - thumb and pinky extended
    if thumb == 1 and index == 0 and middle == 0 and ring == 0 and pinky == 1:
        return 'Y', 0.85
    
    # Peace/V sign - index and middle extended
    if thumb == 0 and index == 1 and middle == 1 and ring == 0 and pinky == 0:
        return 'V', 0.87
    
    # U sign - index and middle together
    if thumb == 0 and index == 1 and middle == 1 and ring == 0 and pinky == 0:
        dist = calculate_distance(landmarks[8], landmarks[12])
        if dist < 0.05:
            return 'U', 0.82
        return 'V', 0.85
    
    # W sign - index, middle, ring extended
    if thumb == 0 and index == 1 and middle == 1 and ring == 1 and pinky == 0:
        return 'W', 0.84
    
    # B sign - four fingers up
    if thumb == 0 and index == 1 and middle == 1 and ring == 1 and pinky == 1:
        return 'B', 0.86
    
    # Closed fist (A or S)
    if extended == 0 or (thumb == 1 and extended == 1):
        thumb_pos = landmarks[4]
        index_base = landmarks[5]
        if thumb_pos.x > index_base.x:
            return 'A', 0.80
        return 'S', 0.78
    
    # I sign - only pinky up
    if thumb == 0 and index == 0 and middle == 0 and ring == 0 and pinky == 1:
        return 'I', 0.89
    
    # D sign - index up, others curved
    if thumb == 0 and index == 1 and middle == 0 and ring == 0 and pinky == 0:
        return 'D', 0.83
    
    # All fingers extended - open hand
    if extended == 5:
        return 'B', 0.70
    
    # O shape
    if extended <= 1:
        dist = calculate_distance(landmarks[4], landmarks[8])
        if dist < 0.08:
            return 'O', 0.82
    
    return None, 0.0

def process_frame(frame_data):
    """Process base64 frame and detect hand gestures"""
    try:
        # Decode base64 image
        img_data = base64.b64decode(frame_data.split(',')[1])
        nparr = np.frombuffer(img_data, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if frame is None:
            return None
        
        # Convert BGR to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(rgb_frame)
        
        detected_gestures = []
        annotated_frame = frame.copy()
        
        if results.multi_hand_landmarks:
            for hand_idx, hand_landmarks in enumerate(results.multi_hand_landmarks):
                # Draw landmarks
                mp_drawing.draw_landmarks(
                    annotated_frame,
                    hand_landmarks,
                    mp_hands.HAND_CONNECTIONS,
                    mp_drawing_styles.get_default_hand_landmarks_style(),
                    mp_drawing_styles.get_default_hand_connections_style()
                )
                
                # Classify gesture
                gesture, confidence = classify_gesture(hand_landmarks.landmark)
                
                if gesture:
                    # Get bounding box
                    h, w, _ = frame.shape
                    x_coords = [lm.x * w for lm in hand_landmarks.landmark]
                    y_coords = [lm.y * h for lm in hand_landmarks.landmark]
                    x1, y1 = int(min(x_coords)) - 10, int(min(y_coords)) - 10
                    x2, y2 = int(max(x_coords)) + 10, int(max(y_coords)) + 10
                    
                    # Draw bounding box
                    cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), (0, 255, 120), 2)
                    
                    # Draw gesture label
                    label = f"{gesture} ({confidence:.0%})"
                    cv2.putText(annotated_frame, label, (x1, y1 - 10),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 120), 2)
                    
                    detected_gestures.append({
                        'gesture': gesture,
                        'confidence': round(confidence * 100, 1),
                        'description': ASL_GESTURES.get(gesture, ''),
                        'hand': 'Right' if hand_idx == 0 else 'Left'
                    })
                
                # Get landmark positions for frontend visualization
                landmark_data = []
                for lm in hand_landmarks.landmark:
                    landmark_data.append({'x': lm.x, 'y': lm.y, 'z': lm.z})
        
        # Encode processed frame
        _, buffer = cv2.imencode('.jpg', annotated_frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
        processed_b64 = base64.b64encode(buffer).decode('utf-8')
        
        return {
            'processed_frame': f'data:image/jpeg;base64,{processed_b64}',
            'gestures': detected_gestures,
            'hand_count': len(results.multi_hand_landmarks) if results.multi_hand_landmarks else 0
        }
    
    except Exception as e:
        print(f"Error processing frame: {e}")
        return None

@app.route('/')
def index():
    return render_template('index.html', asl_gestures=ASL_GESTURES)

@app.route('/api/gestures')
def get_gestures():
    return jsonify(ASL_GESTURES)

@socketio.on('frame')
def handle_frame(data):
    result = process_frame(data['frame'])
    if result:
        emit('result', result)

@socketio.on('connect')
def handle_connect():
    print('Client connected')
    emit('status', {'message': 'Connected to Sign Language Detection Server'})

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

if __name__ == '__main__':
    print("🤟 Sign Language Gesture Detection Server Starting...")
    print("📡 Open http://127.0.0.1:5000 in your browser")
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)
