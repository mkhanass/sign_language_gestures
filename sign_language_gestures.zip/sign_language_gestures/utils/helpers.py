"""
Utility functions for Sign Language Gesture Detection
"""

import numpy as np
import cv2
import base64


def base64_to_frame(base64_string):
    """Convert base64 image string to OpenCV frame"""
    try:
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
        img_data = base64.b64decode(base64_string)
        nparr = np.frombuffer(img_data, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        return frame
    except Exception as e:
        print(f"Error decoding frame: {e}")
        return None


def frame_to_base64(frame, quality=85):
    """Convert OpenCV frame to base64 string"""
    try:
        _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, quality])
        b64 = base64.b64encode(buffer).decode('utf-8')
        return f'data:image/jpeg;base64,{b64}'
    except Exception as e:
        print(f"Error encoding frame: {e}")
        return None


def draw_hand_info(frame, gesture, confidence, bbox):
    """Draw gesture info overlay on frame"""
    x1, y1, x2, y2 = bbox
    
    # Draw bounding box
    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 135), 2)
    
    # Draw label background
    label = f"{gesture} {confidence:.0%}"
    (w, h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.9, 2)
    cv2.rectangle(frame, (x1, y1 - h - 12), (x1 + w + 10, y1), (0, 255, 135), -1)
    
    # Draw label text
    cv2.putText(frame, label, (x1 + 5, y1 - 5),
                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 0), 2)
    
    return frame


def get_hand_bbox(landmarks, frame_w, frame_h, padding=15):
    """Get bounding box from hand landmarks"""
    x_coords = [lm.x * frame_w for lm in landmarks]
    y_coords = [lm.y * frame_h for lm in landmarks]
    
    x1 = max(0, int(min(x_coords)) - padding)
    y1 = max(0, int(min(y_coords)) - padding)
    x2 = min(frame_w, int(max(x_coords)) + padding)
    y2 = min(frame_h, int(max(y_coords)) + padding)
    
    return x1, y1, x2, y2


def normalize_landmarks(landmarks, frame_w, frame_h):
    """Convert landmarks to pixel coordinates"""
    return [(int(lm.x * frame_w), int(lm.y * frame_h)) for lm in landmarks]
